export const recipes = [
  {
    recipe_id: 35382,
    image_url:
      "http://static.food2fork.com/Jalapeno2BPopper2BGrilled2BCheese2BSandwich2B12B500fd186186.jpg",
    title: "Jalapeno Popper Grilled Cheese Sandwich",
    publisher: "Closet Cooking",
    source_url:
      "http://www.closetcooking.com/2011/04/jalapeno-popper-grilled-cheese-sandwich.html"
  },
  {
    recipe_id: 35383,
    image_url:
      "http://static.food2fork.com/Jalapeno2BPopper2BGrilled2BCheese2BSandwich2B12B500fd186186.jpg",
    title: "Jalapeno Popper Grilled Cheese Sandwich",
    publisher: "Closet Cooking",
    source_url:
      "http://www.closetcooking.com/2011/04/jalapeno-popper-grilled-cheese-sandwich.html"
  },
  {
    recipe_id: 35384,
    image_url:
      "http://static.food2fork.com/Jalapeno2BPopper2BGrilled2BCheese2BSandwich2B12B500fd186186.jpg",
    title: "Jalapeno Popper Grilled Cheese Sandwich",
    publisher: "Closet Cooking",
    source_url:
      "http://www.closetcooking.com/2011/04/jalapeno-popper-grilled-cheese-sandwich.html"
  }
];
