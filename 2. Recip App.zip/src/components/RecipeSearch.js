import React, { Component } from 'react'

export default class RecipeSearch extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
